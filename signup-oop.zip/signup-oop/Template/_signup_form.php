<?php
//request method post
if ($_SERVER['REQUEST_METHOD']=='POST') {
	if (isset($_POST['signup_submit'])) {

		//call method adduser
	$Signup->addUser($_POST['first_name'], $_POST['last_name'],$_POST['user_name'], $_POST['user_email'], $_POST['user_pass']);
	}
}
?>
<section id="">
	<div class="container py-5">
		<h4 class="font-rubik font-size-20">Signup</h4>
		<hr>
		
		<form method="POST" accept-charset="utf-8">
			<!-- <input type="text" name="item_id" value="3"> -->
			<!-- <input type="text" name="user_id" value="1"> -->
			<input type="text" name="first_name" value="Abu">
			<input type="text" name="last_name" value="Taher">
			<input type="text" name="user_name" value="taher267">
			<input type="email" name="user_email" value="taher@gmail.com">
			<input type="password" name="user_pass" value="12232114">
			<button type="submit" name="signup_submit" class="btn btn-warning font-size-12">Signup</button>
		</form>
		
	</div>
	<!-- !owl carousel -->
</div>
</section>