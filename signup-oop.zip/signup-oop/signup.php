<?php

include "header.php";
include "Template/_signup_form.php";
include "footer.php";
