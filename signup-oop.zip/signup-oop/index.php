<?php 
ob_start();
include 'header.php';
// Owl-carousel 
include('Template/_banner-area.php');
// Owl-carousel 
//Top Sale -->
include 'Template/_top-sale.php'; 
//Top Sale 
//Special Price
include 'Template/_special-price.php'; 
//Special Price 
//Banner Ads 
include 'Template/_banner_adds.php'; 
//Banner Ads  
//New Phones
include 'Template/_new-phones.php'; 
//New Phones 
//Blogs
include 'Template/_blogs.php';
//Blogs

include 'footer.php';