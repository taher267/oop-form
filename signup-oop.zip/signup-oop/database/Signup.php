<?php
class Signup
{
    public $db = null;
    public function __construct(DBController $db)
     {
        if (!isset($db->con)) return null;
        $this->db=$db;
     }
     public function insertIntoUser($params=null, $table = 'user')
     {
        if ($this->db->con !=null) {
            if ($params !=null) { 
                // "insert into cart('user_id') values(0)"
                // get table columns
               
                $columns = implode(',', array_keys($params));
                // print_r($columns);
                $values = implode("','", array_values($params));
                // print_r($values);
                // exit();
                //create SQL Qry

                $query_string = sprintf("INSERT INTO %s(%s) VALUES('%s')",$table,$columns,$values);
                // echo $query_string;

                //execute Query
                $result = $this->db->con->query($query_string);
                return $result;
            }
        }
     }
     public function addUser($fname, $lname, $uname, $uemail, $upass)
     {

        if (isset($fname) && isset($lname) && isset($uname)&& isset($uemail)&& isset($upass)) {
            $params = array('first_name' => $fname, 'last_name' => $lname, 'user_name' => $uname, 'user_email' => $uemail, 'user_pass' => $upass);
        }

        //insert data into cart
        $result = $this->insertIntoUser($params);
        if ($result) {
            //Reload Page
            header("Location:" . $_SERVER['PHP_SELF']);
        }
     }

    
    
}
