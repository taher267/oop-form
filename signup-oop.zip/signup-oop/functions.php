<?php
//Requice MySQL Connection
 require ('database/DBController.php');
 //require Signup Class
 require 'database/Signup.php';

//DBConnection Object
 $db= new DBController;
 $Signup= new Signup($db);
